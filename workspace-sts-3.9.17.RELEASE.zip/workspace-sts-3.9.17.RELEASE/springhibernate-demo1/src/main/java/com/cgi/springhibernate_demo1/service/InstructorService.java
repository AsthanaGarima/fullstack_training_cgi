package com.cgi.springhibernate_demo1.service;

import com.cgi.springhibernate_demo1.model.Instructor;

public interface InstructorService {

	public Instructor createInstructors(String firstname, String lastname, String email);
}
