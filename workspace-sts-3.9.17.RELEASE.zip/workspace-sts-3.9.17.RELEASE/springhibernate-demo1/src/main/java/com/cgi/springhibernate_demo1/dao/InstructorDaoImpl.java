package com.cgi.springhibernate_demo1.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Component;

import com.cgi.springhibernate_demo1.model.Instructor;

@Component("instructorDao")
public class InstructorDaoImpl implements InstructorDao{

	private SessionFactory sessionFactory;
	
	
	public InstructorDaoImpl(SessionFactory sessionFactory) {
		super();
		this.sessionFactory = sessionFactory;
	}


	@Override
	public Instructor createInstructor(String firstname, String lastname, String email) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		session.getTransaction().begin();
		Instructor instructor = new Instructor(firstname, lastname, email);
		session.save(instructor);
		
		return instructor;
	}

}
