package com.cgi.springhibernate_demo1.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cgi.springhibernate_demo1.dao.InstructorDao;
import com.cgi.springhibernate_demo1.model.Instructor;
import com.cgi.springhibernate_demo1.service.InstructorService;

@Component("instructorService")
public class InstructorServiceImpl implements InstructorService{
	
	@Autowired
	private InstructorDao instructorDao;
	
	

	public InstructorServiceImpl(InstructorDao instructorDao) {
		super();
		this.instructorDao = instructorDao;
	}



	@Override
	public Instructor createInstructors(String firstname, String lastname, String email) {
		// TODO Auto-generated method stub
		return instructorDao.createInstructor(firstname, lastname, email);
	}

}
