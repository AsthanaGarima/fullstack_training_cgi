package com.cgi.springhibernate_demo1;


import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.cgi.springhibernate_demo1.config.SpringConfig;
import com.cgi.springhibernate_demo1.dao.StudentDao;
import com.cgi.springhibernate_demo1.dao.StudentDaoImpl;
import com.cgi.springhibernate_demo1.model.Student;
import com.cgi.springhibernate_demo1.service.StudentService;
import com.cgi.springhibernate_demo1.service.StudentServiceImpl;

/**
 * Hello world!
 *
 */
public class App 
{
	static Scanner scanner = new Scanner(System.in);
    public static void main( String[] args )
    {
    	ApplicationContext context = new AnnotationConfigApplicationContext(SpringConfig.class);
//    	StudentService studentService = context.getBean("studentService", StudentServiceImpl.class);
    	System.out.println("Choose menu") ;
        System.out.println("1:  Student");
        System.out.println("2:  instructor");
        Integer menu = scanner.nextInt();
        switch(menu) {
        case 1:
        	studentOperations(context);
        	break;
        case 2:
        	instructorOperations(context);
        	break;
        }
        
//    	InstructorService instructorService = context.getBean("instructorDao", InstructorServiceImpl.class)
     
    }
    
    public static void studentOperations(ApplicationContext context) {
    
    	StudentService studentService = context.getBean("studentService", StudentServiceImpl.class);
    	 System.out.println("Choose operations") ;
         System.out.println("1: create instructor");
         System.out.println("2: get instructor");
         System.out.println("3: get instructor by id");
         System.out.println("4: update instructor by id");
         System.out.println("5: delete instructor by id");
         System.out.println("6: delete all instructor");
         
         Integer option = scanner.nextInt();
         switch(option) 
         {
         
         case 1:
       	  createStudent(studentService){
       		  
       	  }
       	  break;
       	 
         case 2:
       	  getAllStudent(studentService);
       	  break;
         case 3:
       	  getAllStudentById(studentService);
       	  break;
         case 4:
       	  updateAllStudentById(studentService);
       	  break;
         case 5:
       	  deleteAllStudentById(studentService);
       	  break;
         case 6:
       	  deleteAllStudent(studentService);
       	  break;
         }
         
       
    public static void createStudent(StudentService studentService) {
    	System.out.println("enter id") ;
    	Integer id = scanner.nextInt();
    	System.out.println("enter first name") ;
    	String firstname = scanner.next();
    	System.out.println("enter last name") ;
    	String lastname = scanner.next();
    	System.out.println("enter email") ;
    	String email = scanner.next();
    	
    	Student student = new Student(id, firstname, lastname, email);
    	studentService.createStudents(student);
    }
    
    public static void getAllStudent(StudentService studentService) {
    	studentService.getStudents();
    }
    public static void getAllStudentById(StudentService studentService) {
    	System.out.println("enter id") ;
    	Integer id = scanner.nextInt();
    	studentService.getStudentsById(id);
    }
    
    public static void updateAllStudentById(StudentService studentService) {
    	System.out.println("enter id") ;
    	Integer id = scanner.nextInt();
    	System.out.println("enter first name") ;
    	String firstname = scanner.next();
    	System.out.println("enter last name") ;
    	String lastname = scanner.next();
    	System.out.println("enter email") ;
    	String email = scanner.next();
    	studentService.updateStudentsById(id, firstname, lastname, email);
    }
    
    public static void deleteAllStudentById(StudentService studentService) {
    	System.out.println("enter id") ;
    	Integer id = scanner.nextInt();
    	studentService.deleteStudentsById(id);
    }
    
    public static void deleteAllStudent(StudentService studentService) {
    	studentService.deleteAllStudents();
    }
    }  
}
}

public static void instructorOperation(ApplicationContext context) {
}
}