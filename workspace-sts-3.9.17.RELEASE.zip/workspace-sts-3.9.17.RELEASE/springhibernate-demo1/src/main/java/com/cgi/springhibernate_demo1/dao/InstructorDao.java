package com.cgi.springhibernate_demo1.dao;

import com.cgi.springhibernate_demo1.model.Instructor;

public interface InstructorDao {
	
	public Instructor createInstructor(String firstame, String lastname, String email);

}
