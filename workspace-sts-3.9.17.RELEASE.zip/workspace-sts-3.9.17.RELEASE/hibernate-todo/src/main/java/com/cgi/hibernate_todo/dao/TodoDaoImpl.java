package com.cgi.hibernate_todo.dao;

public class TodoDaoImpl implements TodoDao{

}
