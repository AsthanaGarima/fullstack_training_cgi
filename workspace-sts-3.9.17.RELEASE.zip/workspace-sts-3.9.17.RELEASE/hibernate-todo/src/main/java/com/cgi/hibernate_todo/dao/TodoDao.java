package com.cgi.hibernate_todo.dao;

public interface TodoDao {

}
