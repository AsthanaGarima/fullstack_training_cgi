package com.cgi.hibernate_todo.service;

public class TodoServiceImpl {

}
