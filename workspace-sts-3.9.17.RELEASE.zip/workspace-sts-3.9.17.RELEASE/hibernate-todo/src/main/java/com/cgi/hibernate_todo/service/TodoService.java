package com.cgi.hibernate_todo.service;

public interface TodoService {

}
