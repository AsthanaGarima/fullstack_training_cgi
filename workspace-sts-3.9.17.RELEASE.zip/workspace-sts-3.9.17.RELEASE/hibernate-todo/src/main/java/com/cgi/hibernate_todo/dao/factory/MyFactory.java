package com.cgi.hibernate_todo.dao.factory;

public class MyFactory {

}
