package org.example.demo3.Controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class HomeController {
	
	@RequestMapping("/")
	public String showIndex() {
		return "index";
	}
	
	@RequestMapping(method=RequestMethod.POST, path = "/functions")
	public String functions(HttpServletRequest request) {
		request.setAttribute("ATTR", request.getParameter("t1"));
		
		return "functions";
		
	}

}
