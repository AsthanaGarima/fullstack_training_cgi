package org.example.demo.Controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
@Controller
public class HomeController {
	
	@RequestMapping("/")
	public String showIndex()
	{
		return "index";
	}
	@RequestMapping(method =RequestMethod.POST,path = "/hello")
	public String Hello(HttpServletRequest request)
	{
		request.setAttribute("ATTR1", request.getParameter("t1"));
		request.setAttribute("ATTR2", request.getParameter("t2"));
		return "hello";
	}

}