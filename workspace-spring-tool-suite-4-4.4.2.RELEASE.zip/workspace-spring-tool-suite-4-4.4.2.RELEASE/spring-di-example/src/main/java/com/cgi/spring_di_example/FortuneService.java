package com.cgi.spring_di_example;

public interface FortuneService {

	public String getDailyFortune();
}
