package com.cgi.spring_di_example;

public interface Coach {

	public String getDailyWorkout();
	
	public String getDailyFortune();
}
