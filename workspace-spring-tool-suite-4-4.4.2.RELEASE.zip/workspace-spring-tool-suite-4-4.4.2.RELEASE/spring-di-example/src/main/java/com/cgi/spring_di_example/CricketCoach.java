package com.cgi.spring_di_example;

public class CricketCoach implements Coach{
	private FortuneService fortuneService;
	
	
	public CricketCoach(FortuneService fortuneService) {
		
		this.fortuneService = fortuneService;
	}

	
	public String getDailyWorkout() {
		// TODO Auto-generated method stub
		return "practice spin today";
	}

	
	public String getDailyFortune() {
		// TODO Auto-generated method stub
		return fortuneService.getDailyFortune();
	}

}
