package com.cgi.spring_di_example;

public class HappyFortuneService implements FortuneService{

	public String getDailyFortune() {
		// TODO Auto-generated method stub
		return "today is your lucky day";
	}
	
}
