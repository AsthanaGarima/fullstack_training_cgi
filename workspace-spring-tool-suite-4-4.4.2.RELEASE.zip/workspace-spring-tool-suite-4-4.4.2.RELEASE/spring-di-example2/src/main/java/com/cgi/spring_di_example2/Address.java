package com.cgi.spring_di_example2;

public class Address {
	private String addressLine1;
	private String addressLine2;
	@Override
	public String toString() {
		return "Address [AddressLine1=" + addressLine1 + ", AddressLine2=" + addressLine2 + "]";
	}
	public Address(String addressLine1, String addressLine2) {
		super();
		this.addressLine1 = addressLine1;
		this.addressLine2 = addressLine2;
	}

}
