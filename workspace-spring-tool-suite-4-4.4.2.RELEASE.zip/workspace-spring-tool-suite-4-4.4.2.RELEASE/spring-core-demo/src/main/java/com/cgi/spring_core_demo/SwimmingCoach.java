package com.cgi.spring_core_demo;

public class SwimmingCoach implements Coach{

	public String getDailyWorkout() {
		// TODO Auto-generated method stub
		return "swim atleast 10 times in the pool";
	}

}
