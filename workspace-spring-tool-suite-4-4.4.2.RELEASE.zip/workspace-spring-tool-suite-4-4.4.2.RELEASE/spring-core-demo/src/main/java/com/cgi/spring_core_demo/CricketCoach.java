package com.cgi.spring_core_demo;

public class CricketCoach implements Coach {

	public String getDailyWorkout() {
		// TODO Auto-generated method stub
		return "run 5k today";
	
	
	}

}
