package com.cgi.spring_core_demo;

public interface Coach {
	public String getDailyWorkout();
}
