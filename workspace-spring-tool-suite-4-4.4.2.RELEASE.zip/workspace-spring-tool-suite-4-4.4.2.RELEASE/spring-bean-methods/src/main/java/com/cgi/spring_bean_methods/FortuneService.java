package com.cgi.spring_bean_methods;

public interface FortuneService {

	public String getDailyFortune();
}
