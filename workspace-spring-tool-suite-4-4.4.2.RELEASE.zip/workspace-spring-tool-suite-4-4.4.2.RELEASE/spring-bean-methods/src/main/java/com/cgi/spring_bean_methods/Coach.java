package com.cgi.spring_bean_methods;

public interface Coach {

	public String getDailyWorkout();
	
	public String getDailyFortune();
}
