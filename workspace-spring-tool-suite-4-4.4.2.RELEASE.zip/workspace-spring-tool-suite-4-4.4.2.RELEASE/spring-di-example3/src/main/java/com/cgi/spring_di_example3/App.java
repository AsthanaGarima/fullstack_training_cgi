package com.cgi.spring_di_example3;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
        CricketCoach thecoach = context.getBean("theCoach", CricketCoach.class);
        
        System.out.println(thecoach.getDailyFortune());
        System.out.println(thecoach.getDailyWorkout());
        System.out.println(thecoach.getEmail());
        System.out.println(thecoach.getTeam());
    }
}
