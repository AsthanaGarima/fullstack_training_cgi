package com.cgi.spring_di_example3;

public interface FortuneService {

	public String getDailyFortune();
}
