package com.cgi.spring_jdbc_example;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.sql.DataSource;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args ) throws SQLException
    {
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
        
        DataSource datasource = context.getBean("dataSource", DriverManagerDataSource.class);
        
        Connection conn = datasource.getConnection();
        
        System.out.println(conn);
        System.out.println("connection succeed");
        
        Statement statement = conn.createStatement();
        
        ResultSet resultset = statement.executeQuery("select * from employees");
        
        while(resultset.next()) {
        	System.out.print(resultset.getString("first_name")+ " "+resultset.getString("last_name")+" "+resultset.getString("email"));
        }
        
        
        
        
        
    }
}
