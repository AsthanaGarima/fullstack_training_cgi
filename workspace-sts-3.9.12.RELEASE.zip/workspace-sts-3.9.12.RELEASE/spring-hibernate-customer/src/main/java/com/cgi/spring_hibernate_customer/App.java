package com.cgi.spring_hibernate_customer;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import com.cgi.spring_hibernate_customer.model.Customer;

/**
 * Hello world!
 *
 */
public class App 
{
	static Scanner scanner=new Scanner(System.in);
    public static void main( String[] args )
    {
        SessionFactory factory = new Configuration().configure().addAnnotatedClass(Customer.class).buildSessionFactory()
;    	Session session = factory.openSession();
		session.getTransaction().begin();
		System.out.println("give input");
        Integer option = scanner.nextInt();
        switch(option) {
        case 1:
        	createCustomer(session);
        	break;
        case 2:
        	getAllCustomer(session);
        	break;
        case 3:
        	getCustomerById(session);
        	break;
        
        }
    }
    
    public static void createCustomer(Session session) {
    	session.save(new Customer(200, "Marry", "Public", "marry@email.com"));
        System.out.println("student created...");
//        session.getTransaction().commit();
    }
    
    public static void getAllCustomer(Session session) {
    	  Query query=session.createQuery("FROM Customer");
          java.util.List<Customer> customer= query.getResultList();
          for(Customer c:customer)
          {
          	System.out.println(c);
          }
          
//          session.getTransaction().commit();
    }
    
    public static void getCustomerById(Session session) {
    	System.out.println("Customer id");
    	Integer id = scanner.nextInt();
    	Customer customer = session.find(Customer.class, id);
    	if (customer== null) {
    		System.out.println("no such id");
    	
    	}
    	else {
    		System.out.println(customer);
    	}
    	
        
        session.getTransaction().commit();
    }
}
