package com.example.spring_hibernate_student.dao;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.spring_hibernate_student.model.Student;
import org.hibernate.Session;

@Component("studentDao")
public class StudentDaoImpl implements StudentDao{
	
	@Autowired
	private SessionFactory sessionFactory;
	

	public void addStudent(Student student) {
		
		Session session = sessionFactory.openSession();
		session.beginTransaction().begin();
		
		session.save(student);
		session.getTransaction().commit();
		session.close();
	}

}
