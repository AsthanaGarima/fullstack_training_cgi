package com.example.spring_hibernate_student.dao;

import com.example.spring_hibernate_student.model.Student;

public interface StudentDao {

	public void addStudent(Student student);
}
