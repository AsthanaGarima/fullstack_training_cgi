package com.example.spring_hibernate_student;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.example.spring_hibernate_student.config.SpringConfig;
import com.example.spring_hibernate_student.dao.StudentDao;
import com.example.spring_hibernate_student.dao.StudentDaoImpl;
import com.example.spring_hibernate_student.model.Student;

/**
 * Hello world!
 *
 */
public class App 
{
	static Scanner scanner = new Scanner(System.in);
    public static void main( String[] args )
    {
    	ApplicationContext context = new AnnotationConfigApplicationContext(SpringConfig.class);
    	StudentDaoImpl studentDao = context.getBean("studentDao", StudentDaoImpl.class);
    	System.out.println("Choose options") ;
    	System.out.println("1: add student");
    	Integer option = scanner.nextInt();
    	switch(option) {
    	case 1: 
    		add_student(studentDao);
    		break;
    	}
       
    }
    
    public static void add_student(StudentDaoImpl studentDao) {
    	System.out.println("enter name") ;
    	String name = scanner.next();
    	System.out.println("enter date") ;
    	String date = scanner.next();
    	System.out.println("enter nationality") ;
    	String nationality = scanner.next();
    	System.out.println("enter code") ;
    	String code = scanner.next();
    	
    	Student student = new Student(name, date, nationality, code);
    	studentDao.addStudent(student);
    }
}
