package com.cgi.spring_jdbc_example3;

import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.cgi.spring_jdbc_example3.Dao.CustomerDao;
import com.cgi.spring_jdbc_example3.Service.CustomerService;
import com.cgi.spring_jdbc_example3.config.SpringConfig;
import com.cgi.spring_jdbc_example3.model.Customer;

/**
 * Hello world!
 *
 */
public class App 
{
	static Scanner scanner=new Scanner(System.in);
    public static void main( String[] args )
    {
        ApplicationContext context = new AnnotationConfigApplicationContext(SpringConfig.class);
        
        CustomerService customerService = context.getBean("customerService", CustomerService.class);
        
        List<Customer> list = customerService.getAllCustomers();
        
        for(Customer c:list) {
        	System.out.println(c);
        }
        
//       addCustomer();
        
//        findcustomerbyid();
        
        deletecustomerbyid();
    }
    
    public static void addCustomer() {
    	 System.out.println("Enter id");
         Integer id = scanner.nextInt();
         System.out.println("Enter fname");
         String fname = scanner.next();
         System.out.println("Enter lname");
         String lname = scanner.next();
         System.out.println("Enter email");
         String email = scanner.next();
         ApplicationContext context = new AnnotationConfigApplicationContext(SpringConfig.class);
         CustomerDao customerDao = context.getBean("customerDao", CustomerDao.class);
         
         System.out.println("record succesfully inserted!");
         customerDao.createCustomer(id, fname, lname, email);
         
         
    }
    
    public static void findcustomerbyid() {
   	 System.out.println("Enter id");
        Integer id = scanner.nextInt();
        
        ApplicationContext context = new AnnotationConfigApplicationContext(SpringConfig.class);
        CustomerDao customerDao = context.getBean("customerDao", CustomerDao.class);
        
        List<Customer> list = customerDao.findById(id);
        for(Customer c:list) {
        	System.out.println(c);
        }
        
   }
    
    public static void deletecustomerbyid() {
    	System.out.println("Enter id");
        Integer id = scanner.nextInt();
        
        ApplicationContext context = new AnnotationConfigApplicationContext(SpringConfig.class);
        CustomerDao customerDao = context.getBean("customerDao", CustomerDao.class);
        customerDao.deleteById(id);
        System.out.println("Record deleted succesfully!");
    	
    }
}
