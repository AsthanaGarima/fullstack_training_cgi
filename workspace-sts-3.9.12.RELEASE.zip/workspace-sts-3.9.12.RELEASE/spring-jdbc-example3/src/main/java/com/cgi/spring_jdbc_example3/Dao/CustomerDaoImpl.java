package com.cgi.spring_jdbc_example3.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cgi.spring_jdbc_example3.model.Customer;

@Component("customerDao")
public class CustomerDaoImpl implements CustomerDao {
	
	public final DataSource datasource;

	@Autowired
	public CustomerDaoImpl(DataSource datasource) {
		super();
		this.datasource = datasource;
	}
	
	@Override
	public List<Customer> getAllCustomer() {
		// TODO Auto-generated method stub
		List <Customer> list= new ArrayList<Customer>();
		try {
			
			Connection conn = datasource.getConnection();
			Statement statement = conn.createStatement();
			ResultSet resultset = statement.executeQuery("select * from customer");
			
			while(resultset.next()) {
				System.out.println(resultset.getInt("Customerid")+ " "+resultset.getString("firstname")+ " "+ resultset.getString("lastname")+ " "+ resultset.getString("email"));
			}
			
			
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	public void createCustomer(int id, String fName, String lName, String email) {
		// TODO Auto-generated method stub
//		List <Customer> list= new ArrayList<Customer>();
		try {
			
			Connection conn = datasource.getConnection();
			PreparedStatement statement = conn.prepareStatement("Insert into customer values(?,?,?,?)");
			statement.setInt(1, id);
			statement.setString(2,fName);
			statement.setString(3, lName);
			statement.setString(4,email);
			
			statement.executeUpdate();
			
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

	
	public List<Customer> findById(int id) {
		List <Customer> list= new ArrayList<Customer>();
		try {
			
			Connection conn = datasource.getConnection();
			
			PreparedStatement statement = conn.prepareStatement("select * from customer where customerid= ?");
			statement.setInt(1, id);
			ResultSet resultset = statement.executeQuery();
			while(resultset.next()) {
				System.out.println(resultset.getInt("Customerid")+ " "+resultset.getString("firstname")+ " "+ resultset.getString("lastname")+ " "+ resultset.getString("email"));
			}
			
			
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return list;
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteById(int id) {
		
		try {
			
			Connection conn = datasource.getConnection();
			
			PreparedStatement statement = conn.prepareStatement("delete from customer where customerid= ?");
			statement.setInt(1, id);
			statement.executeUpdate();
		
			
			
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		// TODO Auto-generated method stub
		
	}


}
