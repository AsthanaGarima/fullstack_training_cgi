package com.cgi.spring_jdbc_example3.Dao;

import java.util.List;

import com.cgi.spring_jdbc_example3.model.Customer;

public interface CustomerDao {
	public List<Customer> getAllCustomer();
	public void createCustomer(int id, String fname, String lname,String email);
	public List<Customer> findById(int id);
	public void deleteById(int id);

}
