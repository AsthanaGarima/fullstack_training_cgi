package com.cgi.spring_jdbc_example3.Service;

import java.util.List;
import org.springframework.stereotype.Component;

import com.cgi.spring_jdbc_example3.Dao.CustomerDao;
import com.cgi.spring_jdbc_example3.model.Customer;

@Component("customerService")
public class CustomerServiceImpl implements CustomerService {
	
	private final CustomerDao customerDao;
	
	
	
	public CustomerServiceImpl(CustomerDao customerDao) {
		super();
		this.customerDao = customerDao;
	}



	@Override
	public List<Customer> getAllCustomers() {
		return customerDao.getAllCustomer();
		// TODO Auto-generated method stub
	
	}

}
