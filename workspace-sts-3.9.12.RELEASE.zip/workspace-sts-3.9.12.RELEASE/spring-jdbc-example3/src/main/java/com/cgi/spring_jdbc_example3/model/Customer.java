package com.cgi.spring_jdbc_example3.model;

public class Customer {
	
	private int CustomerId;
	private String Firstname;
	private String Lastname;
	private String Email;
	public int getCustomerId() {
		return CustomerId;
	}
	public void setCustomerId(int customerId) {
		CustomerId = customerId;
	}
	public String getFirstname() {
		return Firstname;
	}
	public void setFirstname(String firstname) {
		Firstname = firstname;
	}
	public String getLastname() {
		return Lastname;
	}
	public void setLastname(String lastname) {
		Lastname = lastname;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public Customer(int customerId, String firstname, String lastname, String email) {
		super();
		CustomerId = customerId;
		Firstname = firstname;
		Lastname = lastname;
		Email = email;
	}
	@Override
	public String toString() {
		return "Customer [CustomerId=" + CustomerId + ", Firstname=" + Firstname + ", Lastname=" + Lastname + ", Email="
				+ Email + "]";
	}
	

}
