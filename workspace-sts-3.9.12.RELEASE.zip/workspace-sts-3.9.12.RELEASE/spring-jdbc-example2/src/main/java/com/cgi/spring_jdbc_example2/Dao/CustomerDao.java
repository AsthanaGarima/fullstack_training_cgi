package com.cgi.spring_jdbc_example2.Dao;

import java.util.List;

import com.cgi.spring_jdbc_example2.model.Customer;

public interface CustomerDao {
	public List<Customer> getAllCustomer();

}
