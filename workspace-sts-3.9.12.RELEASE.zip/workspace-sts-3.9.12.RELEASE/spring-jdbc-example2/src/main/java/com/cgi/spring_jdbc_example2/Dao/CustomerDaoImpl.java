package com.cgi.spring_jdbc_example2.Dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cgi.spring_jdbc_example2.model.Customer;

@Component("customerDao")
public class CustomerDaoImpl implements CustomerDao {
	
	public final DataSource datasource;

	@Autowired
	public CustomerDaoImpl(DataSource datasource) {
		super();
		this.datasource = datasource;
	}
	
	@Override
	public List<Customer> getAllCustomer() {
		// TODO Auto-generated method stub
		List <Customer> list= new ArrayList<Customer>();
		try {
			
			Connection conn = datasource.getConnection();
			Statement statement = conn.createStatement();
			ResultSet resultset = statement.executeQuery("select * from customer");
			
			while(resultset.next()) {
				System.out.println(resultset.getInt("Customerid")+ " "+resultset.getString("firstname")+ " "+ resultset.getString("lastname")+ " "+ resultset.getString("email"));
			}
			
			
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return list;
	}


}
