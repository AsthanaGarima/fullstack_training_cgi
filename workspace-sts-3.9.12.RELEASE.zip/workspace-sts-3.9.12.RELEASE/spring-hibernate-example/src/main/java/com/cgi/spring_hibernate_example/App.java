package com.cgi.spring_hibernate_example;

import com.cgi.spring_hibernate_example.model.Student;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	/*first method */
//        SessionFactory factory=new Configuration().configure().addAnnotatedClass(Student.class).buildSessionFactory();
//        Session session=factory.openSession();
//        session.getTransaction().begin();
//        session.save(new Student(100, "John", "Doe", "john@email.com"));
//        session.getTransaction().commit();
//        System.out.println("student created...");
    	
    	
    	/*second method*/
    	SessionFactory factory=new Configuration().configure().addAnnotatedClass(Student.class).buildSessionFactory();
        Session session=factory.openSession();
        session.getTransaction().begin();
        session.save(new Student(200, "Marry", "Public", "marry@email.com"));
        System.out.println("student created...");
        Query query=session.createQuery("FROM Student");
        java.util.List<Student> students= query.getResultList();
        for(Student s:students)
        {
        	System.out.println(s);
        }
        
        session.getTransaction().commit();
    }
}