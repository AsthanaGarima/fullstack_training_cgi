export interface FortuneService
{​​​​​​
    //default Abstract
    getFortune():string;
}​​​​​​
