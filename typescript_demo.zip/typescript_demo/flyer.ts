export interface flyer{
    land():string;
    takeoff():string;
    fly():string;

}