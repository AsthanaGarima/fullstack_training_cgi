let sportsOne: string[] = ['Golf', 'cricket', 'tennis','swimming']

for (let s of sportsOne){
    console.log(s)
}