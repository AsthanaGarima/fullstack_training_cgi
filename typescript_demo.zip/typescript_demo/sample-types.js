var found = false;
var grade = 91.01;
var firstName = 'Marry';
var lastName = 'Public';
console.log('first name ' + firstName + ' last name ' + lastName + ' found? ' + found + ' Grade ' + grade);
//string templating
console.log('\n using string templating.......');
console.log(" first name ".concat(firstName, " last name ").concat(lastName, " found ").concat(found, " grade ").concat(grade));
