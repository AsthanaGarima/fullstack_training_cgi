export abstract class MyCoach{
    public abstract getDailyWorkout();
    public abstract a();

    public getDetails(){
        
    }
    
}