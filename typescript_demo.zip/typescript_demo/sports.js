var sportsOne = ['Golf', 'cricket', 'tennis', 'swimming'];
for (var _i = 0, sportsOne_1 = sportsOne; _i < sportsOne_1.length; _i++) {
    var s = sportsOne_1[_i];
    console.log(s);
}
