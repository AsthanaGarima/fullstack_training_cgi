"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MyCoach = void 0;
var MyCoach = /** @class */ (function () {
    function MyCoach() {
    }
    MyCoach.prototype.getDetails = function () {
    };
    return MyCoach;
}());
exports.MyCoach = MyCoach;
