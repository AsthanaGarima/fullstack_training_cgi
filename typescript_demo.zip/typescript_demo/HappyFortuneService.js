"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.HappyFortuneService = void 0;
var HappyFortuneService = /** @class */ (function () {
    function HappyFortuneService() {
    }
    HappyFortuneService.prototype.getFortune = function () {
        return "today is happy day....";
    };
    return HappyFortuneService;
}());
exports.HappyFortuneService = HappyFortuneService;
