import { MySwimmingCoach } from "./MySwimmingCoach";

export class MySwimSchedule extends MySwimmingCoach{
    public swimschedule() {
        return "practice at 7 in morning!"
    }
    public getDailyWorkout() {
        return "work out daily!"
    }
    public a() {
        return "a function called"
    }


}