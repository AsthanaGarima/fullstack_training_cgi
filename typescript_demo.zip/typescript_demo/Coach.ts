export interface Coach
{​​​​​​
    //abstract by default
   getDailyWorkout():string;
   getDailyFortune():string;
      
}​​​​​​
