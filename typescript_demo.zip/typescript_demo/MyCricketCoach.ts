import { MyCoach } from "./MyCoach";

export class MyCricketCoach extends MyCoach{
    public getDailyWorkout() {
        return "practice spin bowling!"
    }
    public a() {
        return "hello from function a"
    }
    
}