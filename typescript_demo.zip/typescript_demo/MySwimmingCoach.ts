import { MyCoach } from "./MyCoach";
export abstract class MySwimmingCoach extends MyCoach{

    public abstract swimschedule();

    public  getDetails(){

    }

}