"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.superman = void 0;
var superman = /** @class */ (function () {
    function superman() {
    }
    superman.prototype.land = function () {
        return "superman landed off safely";
    };
    superman.prototype.takeoff = function () {
        return "superman is ready for take off";
    };
    superman.prototype.fly = function () {
        return "superman is flying above in the air";
    };
    return superman;
}());
exports.superman = superman;
