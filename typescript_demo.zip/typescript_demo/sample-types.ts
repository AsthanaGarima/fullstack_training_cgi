let found:boolean=false;
let grade:number=91.01
let firstName:string='Marry';
let lastName:string='Public'
console.log('first name '+firstName+ ' last name '+lastName+' found? ' +found+' Grade '+grade);

//string templating
console.log('\n using string templating.......')
console.log(` first name ${firstName} last name ${lastName} found ${found} grade ${grade}`)