"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SadFortuneService = void 0;
var SadFortuneService = /** @class */ (function () {
    function SadFortuneService() {
    }
    SadFortuneService.prototype.getFortune = function () {
        return "today is your bad day";
    };
    return SadFortuneService;
}());
exports.SadFortuneService = SadFortuneService;
